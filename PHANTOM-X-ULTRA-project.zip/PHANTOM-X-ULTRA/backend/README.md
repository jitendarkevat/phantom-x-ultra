# Backend requirements — production checklist

Do not treat the static frontend as a secure login system. Before real users or active scans:

## Authentication
- Use a reputable identity provider or server-side framework.
- Hash passwords with Argon2id or bcrypt using maintained libraries; never encrypt or store plaintext passwords.
- Email verification and single-use, expiring password-reset tokens.
- Rate limits, abuse detection and safe error messages.
- Secure, HttpOnly, SameSite cookies; CSRF protection where applicable.
- MFA for admins; role-based authorization enforced server-side.
- Keep secrets in server-side environment variables, never frontend code.

## Data and privacy
- Store only necessary user and scan data.
- Define retention/deletion policies, access controls, backups and audit logs.
- Do not store submitted passwords or secrets in logs.
- Obtain consent before collecting data and publish a privacy notice.

## Scanner safety
- Require explicit target ownership/authorization and verify it.
- Allowlist permitted domains/IP ranges; block localhost, private/internal, link-local and cloud metadata destinations unless an isolated lab explicitly requires them.
- Defend against SSRF and DNS rebinding; validate redirects and resolved IPs.
- Apply rate limits, request/time/size limits and a job queue.
- Run scans in isolated workers with minimal privileges.
- Keep audit logs, cancellation controls and clear reports.
- Start with passive checks; enable active tests only in a controlled, authorized environment.

## Integrations
AI, threat-intelligence feeds, live URL reputation, and scan history need server-side integration. API keys must never be placed in frontend JavaScript.
